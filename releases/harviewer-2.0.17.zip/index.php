<!doctype html>
<html>
<head>
    <title>HTTP Archive Viewer 2.0.17</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="css/harViewer.css" type="text/css">
</head>
<body class="harBody">
    <div id="content" version="2.0.17"></div>
    <script src="scripts/jquery.js"></script>
    <script data-main="scripts/harViewer" src="scripts/require.js"></script>
    <?php include("ga.php") ?>
</body>
</html>
